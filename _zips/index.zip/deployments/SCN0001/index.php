<!DOCTYPE html>
<html>
<head>
	<title>Team Nica: Beta Page SCN0001</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="../../hamburger.css">

	<script type="text/javascript">
		function siteData() {

		}
	</script>

</head>

<body onload="siteData()">

	here it is

	<div>
		data container.
		<br>
		Time:
		<br>
		pH:
		<br>
		ORP
		<br>
		target ORP:
		<br>
		other:
	</div>

</body>
</html>